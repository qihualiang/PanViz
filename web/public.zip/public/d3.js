const width = +document.body.getElementsByTagName('canvas')[0].getBoundingClientRect().width;
const height = +document.body.getElementsByTagName('canvas')[0].getBoundingClientRect().height;
const textWidth = 120;
let xDomain, yDomain, x, y, data, filtered, context, toLink, dataContainer;
let windowLeft, windowRight, oriLeft, oriRight, selectedData, interval, canvas, dragIndex, dataBinding;
let dragging = false;

function parseFileData(file, extension, fileName) {
  let format = {
    "bed": {
      "delimiter": " ",
      "parser": function(d, i) {
          var row = {};
					if (d.length != 9) {
						return null;
					}
					row.track = d[0];
					row.start = d[1];
					row.end = d[2];
					row.name = d[3];
					row.file = fileName;
					var rgb = d[8].split(',');
					row.color = rgbToHex(parseInt(rgb[0]), parseInt(rgb[1]), parseInt(rgb[2]));
          if (row.name === "C145" && row.track === "chr8") {
            console.log(row);
            console.log(rgb);
            console.log(row.color);
          }
					return row;
      }
    },
    "gff3": {
      "delimiter": "\t",
      "parser": function(d, i) {
					var row = {};
					if (d.length != 9 || d[2] != 'gene') {
						return null;
					}
					row.track = d[0];
					row.start = d[3];
					row.end = d[4];
					row.file = fileName;
					row.color = '#6f6f6f'
					return row;
      }
    }
  };
  let fileData = d3.dsvFormat(format[extension].delimiter)
                   .parseRows(file, format[extension].parser);
  return fileData;
}

function loadFiles() {
  let files = document.querySelector('input[type=file]').files;
  let loaded = new Array(files.length).fill(false);
  data = [];
  yDomain = [];
  for (let i = 0; i < files.length; i ++) {	  
    let file = files[i];
    let reader = new FileReader();
    yDomain.push(file.name);
    reader.onload = (e)=> {
        let fileExtension = file.name.match(/\.([0-9a-z]+)$/i)[1];
        let fileData= parseFileData(e.target.result, fileExtension, file.name);
        data = data.concat(fileData);
        loaded[i] = true;
        if (loaded.every(t => t === true)) {
          loadFilesCallback(data);
        }
    }
    if (file) {
		  reader.readAsText(file);
	  }
  }
  clear();
  addLoader();
}

function clear() {
  if (canvas) {
    context.fillStyle = "#fff";
    context.rectRect(0,0, width, height);
  }
  d3.selectAll("svg").selectAll("*").remove();
}

function addLoader() {
  d3.select("#loader-container")
    .append("div")
    .attr("class", "spinner-border")
    .attr("role", "status")
    .style("width", "300px")
    .style("height", "300px")
    .select("span")
    .append("span")
    .attr("class", "sr-only")
    .attr("value", "Loading...");
}

function loadFilesCallback(data) {
  resetWindow();
  buildSelector(data);
  bindData(data);
  bindButtons(data);
  draw();
}

function resetWindow() {
  d3.selectAll(".spinner-border").remove();
  toLink = null;
  selectedData = null;
  windowLeft = null;
  windowRight = null;
}

function buildSelector(data) {
	var nestedData = d3.nest().key(function(d) { return d.track}).entries(data);
	var select = d3.select("#inputGroupSelect01")
	select.selectAll("option").remove()
	select.selectAll("option")
		.data(nestedData)
		.enter()
		.append("option")
		.attr("value", function(d) {return d.key})
		.text(function(d) {return d.key;});
  
  select.on('change', function() {
      resetWindow();
      bindData(data);
      draw();
  });
}

function bindButtons(data) {
  d3.select("#zoomIn")
      .on("click", function(e){
        if (windowRight - windowLeft > 1000) {
          let range = windowRight - windowLeft;
          windowRight = windowLeft + range / 2;
          bindData(data);
          draw();
        }
      });
  d3.select("#zoomOut")
    .on("click", function(e){
        if (windowRight - windowLeft < Number.MAX_SAFE_INTEGER / 2) {
          let range = windowRight - windowLeft;
          windowRight = windowLeft + range * 2;
          bindData(data);
          draw();
        }
    });
  d3.select("#moveLeft")
    .on("click", function(e){
      let range = windowRight - windowLeft;
      let step = Math.max(0, Math.min(range / 10, windowLeft));
      windowLeft = windowLeft - step;
      windowRight = windowRight - step;
      bindData(data);
      draw();
    });
  d3.select("#moveRight")
    .on("click", function(e){
      let range = windowRight - windowLeft;
      let step = Math.max(0, Math.min(range / 10, oriRight - windowRight));
      windowLeft = windowLeft + step;
      windowRight = windowRight + step;
      bindData(data);
      draw();
    });
  d3.select("#reset")
    .on("click", function(e) {
      windowRight = oriRight;
      windowLeft = oriLeft;
      bindData(data);
      draw();
  })
  d3.select("#windowLeft")
    .on("change", function(e) {
      windowLeft = Math.max(oriLeft, +d3.select('#windowLeft').property('value'));
      bindData(data);
      draw();
    })
  d3.select("#windowRight")
    .on("change", function(e) {
      windowRight = Math.max(windowLeft, Math.min(oriRight, +d3.select('#windowRight').property('value')));
      bindData(data);
      draw();
    })
  
  d3.select("#search-input")
    .on("change", function(e) {
      selectedData = filtered.filter(function(d) {
        return d.name != null && d3.select("#search-input").property("value") != null 
        && d.name.toLowerCase() == d3.select("#search-input").property("value").toLowerCase();
      })[0];
      if (selectedData == null) {
        alert("Gene not found!");
      }
      var foundSet = {};
      data.forEach(d => {
        if (d.name != null && d3.select("#search-input").property("value") != null 
        && d.name.toLowerCase() == d3.select("#search-input").property("value").toLowerCase()) {
          foundSet[d.track] = 1;
        }
      })
      if (Object.keys(foundSet).length > 0) {
        alert("Gene found in: " + Object.keys(foundSet).join(","));
      }
      if (selectedData != null) {
        toLink = filtered.filter(function(d) {
          return d.name === selectedData.name;                             
        });
      }
      bindData(data);
      draw();
  })
}

function bindData(data) {
  var displayKey = d3.select('select').property('value');
	filtered = data.filter(function(d) {
			 return d.track === displayKey && (windowLeft == null || d.end > windowLeft) && (windowRight == null || d.start < windowRight); 
  });
  
  var detachedContainer = document.createElement("custom");

  // Create a d3 selection for the detached container. We won't
  // actually be attaching it to the DOM.
  dataContainer = d3.select(detachedContainer);
  
  if (windowLeft == null) {
    windowLeft = 0;
    oriLeft = 0;
  }
  if (windowRight == null) {
    windowRight = d3.max(filtered, function(d) { return +d.end; });
    oriRight = windowRight;
  }
  xDomain = [windowLeft, windowRight];	// y.domain...
  
  d3.select("#windowLeft").property("value", Math.round(windowLeft));
  d3.select("#windowRight").property("value", Math.round(windowRight));
  
  y = d3.scaleBand()			// x = d3.scaleBand()	
    .rangeRound([0, Math.min(height, 100 * yDomain.length)])	// .rangeRound([0, width])
    .paddingInner(0.7)
    .align(0.1)
    .domain(yDomain);

  x = d3.scaleLinear()		// y = d3.scaleLinear()
    .domain(xDomain)
    .range([textWidth, width - textWidth]).nice();	// .rangeRound([height, 0]);
  
  dataBinding = dataContainer.selectAll("custom.rect")
  .data(filtered, function(d) { return d; });

  dataBinding.enter()
    .append("custom")
    .classed("rect", true)
    .attr("x", function(d) { return x(+d.start);})
    .attr("y", function(d) { return y(d.file);} )
    .attr("width", function(d) { return x(+d.end) - x(+d.start);})
    .attr("height", function(d) { return y.bandwidth()})
    .attr("fillStyle", function(d) {return d.color});
}

function draw() {
  //clear svg
  d3.selectAll("svg").selectAll("*").remove();
  
  drawXAxis();
  drawTooltip();
  
  if (selectedData != null) {
    d3.select("#search-input").property("value", selectedData.name);
  } else {
    d3.select("#search-input").property("value", "");
  }
  
  canvas = d3.select("canvas")
        .attr("width", width)
        .attr("height", height)
        .style("transform", "translate(0,60px)");
  
  // clear canvas
  context = canvas.node().getContext("2d");
  context.fillStyle = "#fff";
  context.fillRect(0,0, width, height);
  
  var elements = dataContainer.selectAll("custom.rect");
  elements.each(function(d) {
    var node = d3.select(this);
    
    context.beginPath();
    context.fillStyle = node.attr("fillStyle");
    context.fillRect(node.attr("x"), node.attr("y"), node.attr("width"), node.attr("height"));
    context.closePath();
  });
  
  if (toLink) {
    link(toLink);
  }
  
  context.fillStyle = "#fff";
  context.fillRect(0,0, textWidth, height);
  
  context.fillStyle = "#fff";
  context.fillRect(x(windowRight),0, width, height);
  
  yDomain.forEach(t => {
    context.font = "12px Comic Sans MS";
    context.fillStyle = "black";
    context.fillText(t, 0, y(t) + y.bandwidth()/2 + 6, textWidth);
  })
  
  canvas.on("click", onClick);
  canvas.on("mousedown", onMouseDown);
  canvas.on("mouseup", onMouseUp);
  canvas.on("mouseout", onMouseUp);
}

function drawTooltip() {
  if (selectedData != null && selectedData.name != null) {
    var posY = y(selectedData.file) + y.bandwidth() + 60 + 2;
    var posX = (x(+selectedData.start) + x(+selectedData.end)) / 2 - 50/2;
    var tooltip = d3.select("#tooltip-svg")
      .attr("width", 50)
      .attr("height", 30)
      .attr("transform", "translate(" + posX + "," + posY + ")")
      .append("g")
      .attr("class","tippy")
    
    var tooltipRect = tooltip.append("rect")
      .attr("width", 50)
      .attr("height", 30)
      .attr("fill", "white")
      .style("stroke", "black")
      .style("fill-opacity", 0.5)
      .style("stroke-width", 1);

    var tooltipText =tooltip.append("text")
      .attr("dy", 30/2)
      .attr("dx", 50/2)
      .style("text-anchor", "middle")
      .attr("font-size", "30px")
      .attr("font-weight", "bold")
      .text(selectedData.name);
  }
}

function link(data) {
   data.sort(function(a, b){return y(a.file) - y(b.file)});
   for (let i = 1; i < data.length; i++) {
      context.beginPath();
      context.moveTo((x(+data[i - 1].start) + x(+data[i - 1].end))/2, y(data[i-1].file) + y.bandwidth());
      context.lineTo((x(+data[i].start) + x(+data[i].end))/2, y(data[i].file));
      context.stroke();
      context.closePath();
   }
}

function onMouseDown() {
  var mouse = d3.mouse(this);
  var xClicked = x.invert(mouse[0]);
  if (mouse[0] <= 0 || mouse[0] > textWidth) {
      return;
  }
  dragging = true;
  dragIndex = Math.round((mouse[1] / y.step()));
  canvas.on("mousemove", onMouseUpdate);
}

function onMouseUp() {
  if (dragging) {
    dragging = false;
    canvas.on("mousemove", null);
    var mouse = d3.mouse(this);
    var index = Math.round((mouse[1] / y.step()));
    var temp = yDomain[index];
    yDomain[index] = yDomain[dragIndex];
    yDomain[dragIndex] = temp;
    y.domain(yDomain);

    dataContainer.selectAll("custom.rect").remove();
    dataBinding = dataContainer.selectAll("custom.rect")
      .data(filtered, function(d) { return d; });
    dataBinding.enter()
      .append("custom")
      .classed("rect", true)
      .attr("x", function(d) { return x(+d.start);})
      .attr("y", function(d) { return y(d.file);} )
      .attr("width", function(d) { return x(+d.end) - x(+d.start);})
      .attr("height", function(d) { return y.bandwidth()})
      .attr("fillStyle", function(d) {return d.color});
    draw();
  }
}

function onMouseUpdate() {
  mouse = d3.mouse(this);
  context.fillStyle = "#fff";
  context.fillRect(0,0, textWidth, height);

  yDomain.forEach((t, i) => {
    if (i == dragIndex) {
      context.font = "12px Comic Sans MS";
      context.fillStyle = "black";
      context.fillText(t, 0, mouse[1] + y.bandwidth()/2 + 6, textWidth);
    } else {
      context.font = "12px Comic Sans MS";
      context.fillStyle = "black";
      context.fillText(t, 0, y(t) + y.bandwidth()/2 + 6, textWidth);
    }
  })
}

function onClick() {
    toLink = null;
    selectedData = null;
    var mouse = d3.mouse(this);
    
    // map the clicked point to the data space
    var xClicked = x.invert(mouse[0]);
  
    var eachBand = y.step();
    var index = Math.round((mouse[1] / eachBand));
  
    if (mouse[0] > 0 && mouse[0] < textWidth) {
        return;
    }
  
    if ((mouse[1]< y(y.domain()[index]))  || (mouse[1] > y(y.domain()[index]) + y.bandwidth())) {
      draw();
      return;
    }
    var yClicked = y.domain()[index];
    
    selectedData = filtered.filter(function(d) {
      return d.file === yClicked && d.start <= xClicked && d.end >= xClicked;
    })[0];
    if (selectedData != null && selectedData.name != null) {
      toLink = filtered.filter(function(d) {
        return d.name === selectedData.name;                             
      });
    }
    draw();
}

function drawXAxis() {
  var svg = d3.select("#axis-svg") 
        .attr("width", width)
        .attr("height", height)
        .append("g");
  
  var xAxis = d3.axisTop(x)
      .ticks(10);
  
  var xAxisSvg = svg.append('g')
        .attr('class', 'x axis')
        .attr('transform', 'translate(0,20)')
        .call(xAxis);
}

function rgbToHex(r, g, b) {
  return "#" + componentToHex(r) + componentToHex(g) + componentToHex(b);
}

function componentToHex(c) {
  var hex = c.toString(16);
  return hex.length == 1 ? "0" + hex : hex;
}